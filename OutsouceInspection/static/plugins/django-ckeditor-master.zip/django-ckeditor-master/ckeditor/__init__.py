VERSION = (6, 1, 0)
__version__ = ".".join(map(str, VERSION))
