﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","it",{button:"Inserisci frammento di codice",codeContents:"Contenuto del codice",emptySnippetError:"Un frammento di codice non può essere vuoto.",language:"Lingua",title:"Frammento di codice",pathName:"frammento di codice"});